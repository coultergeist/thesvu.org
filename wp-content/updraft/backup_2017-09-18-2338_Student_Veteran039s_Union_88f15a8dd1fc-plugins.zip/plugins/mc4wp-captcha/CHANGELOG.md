Changelog
=========

#### 1.0.2 - August 2, 2016

**Improvements**

- Compatibility with [upcoming MailChimp for WordPress 4.0 release](https://mc4wp.com/kb/upgrading-to-4-0/).


#### 1.0.1 - March 1, 2016

**Fixes**

- Captcha validation always passing, regardless of input value.


#### 1.0 - November 23, 2015

Initial release.