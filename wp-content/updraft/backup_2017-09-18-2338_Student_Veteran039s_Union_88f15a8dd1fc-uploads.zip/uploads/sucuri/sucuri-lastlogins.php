<?php exit(0); ?>
{"user_id":1,"user_login":"svu_admin","user_remoteaddr":"71.212.65.201","user_hostname":"71-212-65-201.tukw.qwest.net","user_lastlogin":"2017-09-05 15:30:32"}
{"user_id":1,"user_login":"svu_admin","user_remoteaddr":"71.217.35.44","user_hostname":"71-217-35-44.tukw.qwest.net","user_lastlogin":"2017-09-07 04:37:49"}
