<?php
/**
 * Display section heading in settings area.
 *
 * @author 	Studio 164a
 * @package Charitable/Admin View/Settings
 * @since 	1.0.0
 */
?>
<hr />