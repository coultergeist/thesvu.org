<?php exit(0); ?>
{"user_login":"svu_admin","user_password":"[hidden]","attempt_time":1505467337,"remote_addr":"178.137.82.201","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64; rv:50.0) Gecko\/20100101 Firefox\/50.0"}
