<?php
// datastore=auditlogs;
// created_on=1504566271;
// updated_on=1504566271;
exit(0);
?>
response:{"status":1,"action":"get_logs","request_time":1504566318,"verbose":0,"output":["2017-09-04 19:05:10 danielle.coulter@thesvu.org : INFO: Authentication key added and plugin enabled"],"total_entries":1,"output_data":[{"event":"notice","date":"2017-09-04","time":"23:05:10","datetime":"2017-09-04 23:05:10","timestamp":1504566310,"account":"danielle.coulter@thesvu.org","username":"system","remote_addr":"127.0.0.1","message":"INFO: Authentication key added and plugin enabled","file_list":false,"file_list_count":0}]}
