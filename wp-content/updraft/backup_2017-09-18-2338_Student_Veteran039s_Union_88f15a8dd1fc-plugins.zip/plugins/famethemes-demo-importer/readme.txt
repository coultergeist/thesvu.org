=== Plugin Name ===
Contributors: famethemes, shrimp2t
Donate link: https://www.famethemes.com/
Tags: import, demo data, oneclick, famethemes
Requires at least: 4.5
Tested up to: 4.6
Stable tag: 4.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

FameThemes Demo importer

== Description ==

Import demo content for FameThemes’s themes with just one click.

Working with themes:

- [Screenr](https://wordpress.org/themes/screenr/)
- [Boston](https://wordpress.org/themes/boston/).
- [OnePress](https://wordpress.org/themes/onepress/)

== Installation ==

1. Upload `famethemes-demo-importer` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Appereance -> (Theme Name) -> Select tab One Click Demo Import



== Changelog ==
= 1.0.2
* Add recommend plugins notices.

= 1.0.1
* Improve and fix bug.

= 1.0.0 =
* Release

